package it.unicam.filiera.repositories;

import it.unicam.filiera.models.Curatore;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CuratoreRepository extends JpaRepository<Curatore, Long> {}
