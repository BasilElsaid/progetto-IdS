package it.unicam.filiera.controllers;

import it.unicam.filiera.controllers.dto.UtenteResponse;
import it.unicam.filiera.services.UtentiService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UtentiController {

    private final UtentiService service;

    public UtentiController(UtentiService service) {
        this.service = service;
    }

    
    public List<UtenteResponse> all() {
        return service.tutti();
    }
    

    @GetMapping("/{id}") 
    public UtenteResponse byId(@PathVariable Long id)  {
        return service.perId(id);
    }

    
    @GetMapping("/me")
    public UtenteResponse me(@RequestParam Long userId) {
        return service.perId(userId);
    }
}
