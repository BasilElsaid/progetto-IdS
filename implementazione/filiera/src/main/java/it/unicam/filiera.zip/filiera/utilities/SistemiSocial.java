package it.unicam.filiera.utilities;

public class SistemiSocial {

	private String url;

}