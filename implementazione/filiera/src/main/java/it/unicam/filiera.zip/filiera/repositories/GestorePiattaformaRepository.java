package it.unicam.filiera.repositories;

import it.unicam.filiera.models.GestorePiattaforma;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GestorePiattaformaRepository extends JpaRepository<GestorePiattaforma, Long> {}
