package it.unicam.filiera.domain;

public class Pagamento {

	private String metodo;

}