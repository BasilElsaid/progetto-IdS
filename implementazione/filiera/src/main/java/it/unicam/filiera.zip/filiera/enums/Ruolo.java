package it.unicam.filiera.enums;

public enum Ruolo {
    UTENTE_GENERICO,
    ACQUIRENTE,
    PRODUTTORE,
    TRASFORMATORE,
    CURATORE,
    ANIMATORE,
    DISTRIBUTORE_TIPICITA,
    GESTORE_PIATTAFORMA
}
