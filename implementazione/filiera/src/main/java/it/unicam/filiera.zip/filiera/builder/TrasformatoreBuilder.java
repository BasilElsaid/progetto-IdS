package it.unicam.filiera.builder;

public class TrasformatoreBuilder implements UtenteBuilder {

	/**
	 * @param username
	 */
	@Override
	public void setUsername(String username) {

	}

	/**
	 * @param password
	 */
	@Override
	public void setPassword(String password) {

	}

	/**
	 * @param nome
	 */
	@Override
	public void setNome(String nome) {

	}

	/**
	 * @param email
	 */
	@Override
	public void setEmail(String email) {

	}

	/**
	 * @param telefono
	 */
	@Override
	public void setTelefono(String telefono) {

	}

	public void build() {
		// TODO - implement TrasformatoreBuilder.build
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param pIVA
	 */
	public void setPartitaIVA(String pIVA) {
		// TODO - implement TrasformatoreBuilder.setPartitaIVA
		throw new UnsupportedOperationException();
	}

}