package it.unicam.filiera.utilities;

public class CoordinateOSM {

	private double lat;
	private double lon;

	public double getLat() {
		return this.lat;
	}

	public double getLon() {
		return this.lon;
	}

	/**
	 * 
	 * @param lat
	 * @param lon
	 */
	public CoordinateOSM(double lat, double lon) {
		// TODO - implement CoordinateOSM.CoordinateOSM
		throw new UnsupportedOperationException();
	}

}