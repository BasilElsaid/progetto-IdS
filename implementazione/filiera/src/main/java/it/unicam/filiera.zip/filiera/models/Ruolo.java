package it.unicam.filiera.models;

public enum Ruolo {
    UTENTE_GENERICO,   
    ACQUIRENTE,
    PRODUTTORE,
    TRASFORMATORE,
    CURATORE,
    ANIMATORE,
    GESTORE_PIATTAFORMA,
    DISTRIBUTORE_TIPICITA
}
