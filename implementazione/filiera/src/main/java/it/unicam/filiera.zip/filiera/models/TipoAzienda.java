package it.unicam.filiera.models;

public enum TipoAzienda {
    PRODUTTORE,
    TRASFORMATORE,
    DISTRIBUTORE
}
