package it.unicam.filiera.services;

import it.unicam.filiera.controllers.dto.UtenteResponse;
import it.unicam.filiera.exceptions.NotFoundException;
import it.unicam.filiera.models.UtenteGenerico;
import it.unicam.filiera.repositories.UtenteRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UtentiService {

    private final UtenteRepository repo;

    public UtentiService(UtenteRepository repo) {
        this.repo = repo;
    }

    public List<UtenteResponse> tutti() {
        return repo.findAll().stream().map(UtenteResponse::from).toList();
    }

    public UtenteResponse perId(Long id) {
        UtenteGenerico u = repo.findById(id).orElseThrow(() -> new NotFoundException("Utente non trovato"));
        return UtenteResponse.from(u);
    }
}
