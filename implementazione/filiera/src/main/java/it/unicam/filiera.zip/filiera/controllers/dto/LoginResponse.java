package it.unicam.filiera.controllers.dto;

public record LoginResponse(
        String token
) {}