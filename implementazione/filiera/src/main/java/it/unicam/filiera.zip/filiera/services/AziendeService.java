package it.unicam.filiera.services;

import it.unicam.filiera.builder.DistributoreTipicitaBuilder;
import it.unicam.filiera.builder.ProduttoreBuilder;
import it.unicam.filiera.builder.TrasformatoreBuilder;
import it.unicam.filiera.controllers.dto.CoordinateDTO;
import it.unicam.filiera.controllers.dto.CreateAziendaRequest;
import it.unicam.filiera.controllers.dto.UtenteResponse;
import it.unicam.filiera.exceptions.BadRequestException;
import it.unicam.filiera.exceptions.NotFoundException;
import it.unicam.filiera.models.Azienda;
import it.unicam.filiera.models.DistributoreTipicita;
import it.unicam.filiera.models.Produttore;
import it.unicam.filiera.models.Trasformatore;
import it.unicam.filiera.enums.Ruolo;
import it.unicam.filiera.repositories.DistributoreTipicitaRepository;
import it.unicam.filiera.repositories.ProduttoreRepository;
import it.unicam.filiera.repositories.TrasformatoreRepository;
import it.unicam.filiera.utilities.CoordinateOSM;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AziendeService {

    private final ProduttoreRepository produttoreRepo;
    private final TrasformatoreRepository trasformatoreRepo;
    private final DistributoreTipicitaRepository distributoreRepo;
    private final PasswordEncoder passwordEncoder;

    public AziendeService(
            ProduttoreRepository produttoreRepo,
            TrasformatoreRepository trasformatoreRepo,
            DistributoreTipicitaRepository distributoreRepo,
            PasswordEncoder passwordEncoder
    ) {
        this.produttoreRepo = produttoreRepo;
        this.trasformatoreRepo = trasformatoreRepo;
        this.distributoreRepo = distributoreRepo;
        this.passwordEncoder = passwordEncoder;
    }

    public Azienda creaAzienda(CreateAziendaRequest request) {
        Ruolo ruolo = request.getRuolo();
        switch (ruolo) {
            case PRODUTTORE -> {
                Produttore p = new ProduttoreBuilder()
                        .setUsername(request.getUsername())
                        .setPassword(passwordEncoder.encode(request.getPassword()))                        .setEmail(request.getEmail())
                        .setNomeAzienda(request.getNomeAzienda())
                        .setPartitaIva(request.getPartitaIva())
                        .setCoordinate(toCoordinate(request.getCoordinate()))
                        .build();
                return produttoreRepo.save(p);
            }
            case TRASFORMATORE -> {
                Trasformatore t = new TrasformatoreBuilder()
                        .setUsername(request.getUsername())
                        .setPassword(passwordEncoder.encode(request.getPassword()))                        .setEmail(request.getEmail())
                        .setNomeAzienda(request.getNomeAzienda())
                        .setPartitaIva(request.getPartitaIva())
                        .setLaboratorio(request.getLaboratorio())
                        .setCoordinate(toCoordinate(request.getCoordinate()))
                        .build();
                return trasformatoreRepo.save(t);
            }
            case DISTRIBUTORE_TIPICITA -> {
                DistributoreTipicita d = new DistributoreTipicitaBuilder()
                        .setUsername(request.getUsername())
                        .setPassword(passwordEncoder.encode(request.getPassword()))                        .setEmail(request.getEmail())
                        .setNomeAzienda(request.getNomeAzienda())
                        .setPartitaIva(request.getPartitaIva())
                        .setSede(request.getSede())
                        .setAreaDistribuzione(request.getAreaDistribuzione())
                        .setCoordinate(toCoordinate(request.getCoordinate()))
                        .build();
                return distributoreRepo.save(d);
            }
            default -> throw new BadRequestException("Ruolo non gestito dal sistema");
        }
    }

    public List<UtenteResponse> listaAziende() {
        List<UtenteResponse> out = new ArrayList<>();
        produttoreRepo.findAll().forEach(u -> out.add(UtenteResponse.from(u)));
        trasformatoreRepo.findAll().forEach(u -> out.add(UtenteResponse.from(u)));
        distributoreRepo.findAll().forEach(u -> out.add(UtenteResponse.from(u)));
        return out;
    }

    public UtenteResponse getAzienda(Long id) {
        return UtenteResponse.from(findAziendaById(id));
    }

    public UtenteResponse patchAzienda(Long id, CreateAziendaRequest request) {
        Azienda azienda = findAziendaById(id);

        updateBaseFields(azienda, request);

        if (azienda instanceof Trasformatore t && request.getLaboratorio() != null) {
            t.setLaboratorio(request.getLaboratorio());
        }

        if (azienda instanceof DistributoreTipicita d && request.getAreaDistribuzione() != null) {
            d.setAreaDistribuzione(request.getAreaDistribuzione());
        }

        return UtenteResponse.from(saveAzienda(azienda));
    }

    public void deleteAzienda(Long id) {
        Azienda azienda = findAziendaById(id);
        deleteAziendaByTipo(azienda);
    }

    // ================= HELPERS =================
    private CoordinateOSM toCoordinate(CoordinateDTO dto) {
        return dto == null ? null : new CoordinateOSM(dto.lat, dto.lon);
    }

    private void updateBaseFields(Azienda a, CreateAziendaRequest request) {
        if (request.getEmail() != null) a.setEmail(request.getEmail());
        if (request.getPassword() != null) a.setPassword(request.getPassword());
        if (request.getNomeAzienda() != null) a.setNomeAzienda(request.getNomeAzienda());
        if (request.getPartitaIva() != null) a.setPartitaIva(request.getPartitaIva());
        if (request.getCoordinate() != null) a.setCoordinate(toCoordinate(request.getCoordinate()));
    }

    private Azienda findAziendaById(Long id) {
        return produttoreRepo.findById(id).map(a -> (Azienda) a)
                .or(() -> trasformatoreRepo.findById(id).map(a -> (Azienda) a))
                .or(() -> distributoreRepo.findById(id).map(a -> (Azienda) a))
                .orElseThrow(() -> new NotFoundException("Azienda non trovata"));
    }

    private Azienda saveAzienda(Azienda a) {
        if (a instanceof Produttore p) return produttoreRepo.save(p);
        if (a instanceof Trasformatore t) return trasformatoreRepo.save(t);
        if (a instanceof DistributoreTipicita d) return distributoreRepo.save(d);
        throw new IllegalStateException("Tipo di azienda non supportato");
    }

    private void deleteAziendaByTipo(Azienda a) {
        if (a instanceof Produttore p) produttoreRepo.delete(p);
        else if (a instanceof Trasformatore t) trasformatoreRepo.delete(t);
        else if (a instanceof DistributoreTipicita d) distributoreRepo.delete(d);
    }
}