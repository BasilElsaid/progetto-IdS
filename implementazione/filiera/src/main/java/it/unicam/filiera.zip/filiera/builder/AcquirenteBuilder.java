package it.unicam.filiera.builder;

public class AcquirenteBuilder implements UtenteBuilder {

	/**
	 * @param username
	 */
	@Override
	public void setUsername(String username) {

	}

	/**
	 * @param password
	 */
	@Override
	public void setPassword(String password) {

	}

	/**
	 * @param nome
	 */
	@Override
	public void setNome(String nome) {

	}

	/**
	 * @param email
	 */
	@Override
	public void setEmail(String email) {

	}

	/**
	 * @param telefono
	 */
	@Override
	public void setTelefono(String telefono) {

	}

	public void build() {
		// TODO - implement AcquirenteBuilder.build
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param cognome
	 */
	public void setCognome(String cognome) {
		// TODO - implement AcquirenteBuilder.setCognome
		throw new UnsupportedOperationException();
	}

}