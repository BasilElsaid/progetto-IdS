package it.unicam.filiera.enums;

public enum TipoCertificatore {
    PRODUTTORE,
    TRASFORMATORE,
    CURATORE
}


