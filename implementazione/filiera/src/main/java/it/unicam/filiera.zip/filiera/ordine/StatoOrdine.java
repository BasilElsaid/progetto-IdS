package it.unicam.filiera.ordine;

public enum StatoOrdine {
    CREATO,
    PAGATO,
    SPEDITO,
    CONSEGNATO,
    ANNULLATO
}
