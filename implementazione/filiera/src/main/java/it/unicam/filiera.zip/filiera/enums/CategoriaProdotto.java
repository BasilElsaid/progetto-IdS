package it.unicam.filiera.enums;

public enum CategoriaProdotto {
    ORTOFRUTTA,
    OLIO,
    VINO,
    LATTE_E_DERIVATI,
    CEREALI_E_FARINE,
    CARNE_E_SALUMI,
    MIELE,
    CONSERVE,
    ALTRO
}
