package it.unicam.filiera.models;

public enum UnitaMisura {
    KG,
    G,
    L,
    ML,
    PEZZO
}
