package it.unicam.filiera.repositories;

import it.unicam.filiera.models.Animatore;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnimatoreRepository extends JpaRepository<Animatore, Long> {}
