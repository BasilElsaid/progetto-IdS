package it.unicam.filiera.models;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("DISTRIBUTORE")
public class DistributoreTipicita extends UtenteGenerico {

    private String areaDistribuzione;

    public DistributoreTipicita() {
        setRuolo(Ruolo.DISTRIBUTORE_TIPICITA);
    }

    public String getAreaDistribuzione() { return areaDistribuzione; }
    public void setAreaDistribuzione(String areaDistribuzione) { this.areaDistribuzione = areaDistribuzione; }
}
