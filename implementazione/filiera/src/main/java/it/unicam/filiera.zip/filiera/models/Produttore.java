package it.unicam.filiera.models;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("PRODUTTORE")
public class Produttore extends UtenteGenerico {
    public Produttore() {
        setRuolo(Ruolo.PRODUTTORE);
    }
}
