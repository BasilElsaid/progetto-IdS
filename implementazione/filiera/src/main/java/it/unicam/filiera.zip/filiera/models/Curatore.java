package it.unicam.filiera.models;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("CURATORE")
public class Curatore extends UtenteGenerico {

  

    public Curatore() {
        setRuolo(Ruolo.CURATORE);
    }
}
