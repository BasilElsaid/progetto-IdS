package it.unicam.filiera.controllers.dto;

public class AddCertificazioneRequest {
     public String nome;
    public boolean approvata;
    public String ente;
    public String note;
	public String nome() {
		// TODO Auto-generated method stub
		return null;
	}
}
