package it.unicam.filiera.ordine;

public class Pagamento {

	private String metodo;

}