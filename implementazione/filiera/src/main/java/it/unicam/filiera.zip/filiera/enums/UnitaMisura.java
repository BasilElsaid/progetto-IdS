package it.unicam.filiera.enums;

public enum UnitaMisura {
    KG,
    G,
    L,
    ML,
    PEZZO
}
