package it.unicam.filiera.models;

public enum TipoCertificatore {
    PRODUTTORE,
    TRASFORMATORE,
    CURATORE
}


