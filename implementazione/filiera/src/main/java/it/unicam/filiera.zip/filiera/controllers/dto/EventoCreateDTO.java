package it.unicam.filiera.controllers.dto;

public class EventoCreateDTO {
    public String nome;
    public String dataOra;
    public double prezzo;
    public String tipo;
    public int posti;
    // niente animatoreId
}