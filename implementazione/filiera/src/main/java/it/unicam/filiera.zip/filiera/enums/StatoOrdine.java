package it.unicam.filiera.enums;

public enum StatoOrdine {
    CREATO,
    PAGATO,
    SPEDITO,
    CONSEGNATO,
    ANNULLATO
}
