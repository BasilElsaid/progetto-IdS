package it.unicam.filiera.controllers.dto;

import java.math.BigDecimal;

public class UpdateProdottoRequest {
    public String nome;
    public String descrizione;
    public String categoria;
    public String lotto;
    public BigDecimal prezzo;
}
